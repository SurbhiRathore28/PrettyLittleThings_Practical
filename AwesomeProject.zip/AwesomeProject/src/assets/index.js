export const CART_ICON = require('./Images/bag.png')
export const DASHBOARD_IMAGE = require('./Images/shopping.png')