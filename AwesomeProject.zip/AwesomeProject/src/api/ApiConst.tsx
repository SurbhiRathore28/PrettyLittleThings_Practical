export const BASE_URL = 'https://my-json-server.typicode.com/benirvingplt'
export const END_POINT = {
    PRODUCT_LISTING: '/products/products'
}